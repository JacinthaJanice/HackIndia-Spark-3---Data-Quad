/**
require("@nomiclabs/hardhat-waffle");
require("dotenv").config();
const PRIVATE_KEY=process.env.PRIVATE_KEY;
module.exports = {
  solidity: "0.8.0",
  networks: {
    rinkeby: {
      url: "https://polygon-amoy.g.alchemy.com/v2/6unI6DF7EqTyg4juup3UISXU5j4rDEP4",
      accounts: [`0x${"590da6e2e1b6c3627b4f8aa3cb70c28fb36e1f3e438627f4daf6da0a208e75ac"}`]
    }
  }
};
*/
/** 
require("@nomiclabs/hardhat-waffle");
require("dotenv").config();

module.exports = {
  solidity: "0.8.0",
  networks: {
    polygon: {
      url: process.env.ALCHEMY_URL,
      accounts: [`0x${process.env.PRIVATE_KEY}`]
    }
  }
};
*/
require('@nomiclabs/hardhat-waffle');
require('dotenv').config();

// const { ALCHEMY_API_KEY, PRIVATE_KEY } = process.env;

module.exports = {
  solidity: "0.8.0",
  networks: {
    // mainnet: {
    //   url: `https://polygon-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}`,
    //   accounts: [`0x${PRIVATE_KEY}`]
    // },
    amoy: {
      url: process.env.ALCHEMY_URL,
      accounts: [process.env.PRIVATE_KEY]
    },
  },
};




