const { ethers } = require("ethers");

// Load environment variables
require('dotenv').config();

const privateKey = process.env.PRIVATE_KEY;
const provider = new ethers.providers.JsonRpcProvider(`https://polygon-mainnet.g.alchemy.com/v2/6unI6DF7EqTyg4juup3UISXU5j4rDEP4`);
const wallet = new ethers.Wallet(privateKey, provider);

async function deployContract() {
    const factory = new ethers.ContractFactory(abi, bytecode, wallet);
    const contract = await factory.deploy();

    console.log("Contract deployed at address:", contract.address);
}

deployContract();
