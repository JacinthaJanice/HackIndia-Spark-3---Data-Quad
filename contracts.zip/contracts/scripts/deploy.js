// require('dotenv').config();
// const { ethers } = require("hardhat");
/** 
async function main() {
    // Get the deployer account
     const [deployer] = await ethers.getSigners();

     console.log("Deploying contracts with the account:", deployer.address);

     // Compile and deploy the contract
     const Token = await ethers.getContractFactory("YourContract");
     const token = await Token.deploy();

    console.log("Contract deployed to address:", token.address);
}

// // Run the deployment script
main()
     .then(() => process.exit(0))
     .catch(error => {
         console.error(error);
         process.exit(1);
     });

// // const { ethers } = require("hardhat");
// // require('dotenv').config();

// // Load environment variables
 const privateKey = process.env.PRIVATE_KEY;
 const alchemyUrl = process.env.ALCHEMY_URL;

// // // Set up provider and wallet
//  const provider = new ethers.provider.JsonRpcProvider('https://polygon-amoy.g.alchemy.com/v2/6unI6DF7EqTyg4juup3UISXU5j4rDEP4');
const wallet = new ethers.Wallet(privateKey, provider);

const { ethers } = require("hardhat");

// Example: Connecting to the Polygon Mainnet using an Alchemy API URL
// const alchemyUrl = "https://polygon-amoy.g.alchemy.com/v2/6unI6DF7EqTyg4juup3UISXU5j4rDEP4";
const provider = new ethers.providers.JsonRpcProvider(alchemyUrl);

// Example: Fetching the balance of an address
async function getBalance(address) {
    const balance = await provider.getBalance(address);
    console.log(`Balance of ${address}:`, ethers.utils.formatEther(balance));
}

// Replace with an actual Ethereum address
getBalance("0xYourEthereumAddressHere");


// Replace with your contract's ABI and bytecode
const abi =[
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "_unlockTime",
          "type": "uint256"
        }
      ],
      "stateMutability": "payable",
      "type": "constructor"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "amount",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "when",
          "type": "uint256"
        }
      ],
      "name": "Withdrawal",
      "type": "event"
    },
    {
      "inputs": [],
      "name": "owner",
      "outputs": [
        {
          "internalType": "address payable",
          "name": "",
          "type": "address"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "unlockTime",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "withdraw",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ]; 
  */
 // Ensure this is at the top of your file
 const { ethers } = require("hardhat");

 async function main() {
     // Get the deployer account
     const [deployer] = await ethers.getSigners();
     console.log("Deploying contracts with the account:", deployer.address);
 
     // Compile and deploy the contract
     const contract = await (await ethers.getContractFactory("AgricultureMarketplace")).deploy();
 
     console.log("Contract deployed to address:", contract.address);
 }
 
 // Run the deployment script
 main()
     .then(() => process.exit(0))
     .catch(error => {
         console.error(error);
         process.exit(1);
     });
 
 